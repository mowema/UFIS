This is a custom action for the ChronoForms v4 forms extension for Joomla! 2.5

To install this action please use the Install Action icon 
in the ChronoForms Forms Manager Toolbar.
More help is available on the action tips and help tab.


    This action is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    There should be a copy of the GNU General Public License
    in the root folder of your Joomla! installation.
    If not, see <http://www.gnu.org/licenses/>.